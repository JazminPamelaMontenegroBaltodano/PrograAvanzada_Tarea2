﻿using System.ComponentModel.DataAnnotations;

namespace TareaProgra2MVC.Models
{
    public class TrianguloModel
    {
        [Required, Range(0.0001, double.MaxValue, ErrorMessage = "El lado a debe ser mayor que 0.")]
        public double a { get; set; }

        [Required, Range(0.0001, double.MaxValue, ErrorMessage = "El lado b debe ser mayor que 0.")]
        public double b { get; set; }

        [Required, Range(0.0001, double.MaxValue, ErrorMessage = "El lado c debe ser mayor que 0.")]
        public double c { get; set; }

        // Resultados
        public double Perimetro { get; set; }
        public double Semiperimetro { get; set; }
        public double Area { get; set; }
        public string Tipo { get; set; }

        public double Alpha { get; set; }
        public double Beta { get; set; }
        public double Gamma { get; set; }
    }
}