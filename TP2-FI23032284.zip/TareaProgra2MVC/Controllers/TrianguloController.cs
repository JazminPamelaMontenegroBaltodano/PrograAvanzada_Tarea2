﻿using System;
using System.Web.Mvc;
using TareaProgra2MVC.Models;

namespace TareaProgra2MVC.Controllers
{
    public class TrianguloController : Controller
    {
        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(TrianguloModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            // Validación de desigualdad triangular
            double[] lados = { model.a, model.b, model.c };
            Array.Sort(lados); // ordenar lados de menor a mayor
            if (lados[0] + lados[1] <= lados[2])
            {
                ModelState.AddModelError("", "La suma de los dos lados menores debe ser mayor que el lado mayor.");
                return View(model);
            }

            // Cálculos
            model.Perimetro = model.a + model.b + model.c;
            model.Semiperimetro = model.Perimetro / 2;
            model.Area = Math.Sqrt(model.Semiperimetro *
                                  (model.Semiperimetro - model.a) *
                                  (model.Semiperimetro - model.b) *
                                  (model.Semiperimetro - model.c));

            // Determinar tipo de triángulo
            if (model.a == model.b && model.b == model.c)
                model.Tipo = "Equilátero";
            else if (model.a == model.b || model.a == model.c || model.b == model.c)
                model.Tipo = "Isósceles";
            else
                model.Tipo = "Escaleno";

            // Calcular ángulos usando la ley de cosenos
            model.Alpha = Math.Acos((Math.Pow(model.b, 2) + Math.Pow(model.c, 2) - Math.Pow(model.a, 2)) / (2 * model.b * model.c)) * (180 / Math.PI);
            model.Beta = Math.Acos((Math.Pow(model.a, 2) + Math.Pow(model.c, 2) - Math.Pow(model.b, 2)) / (2 * model.a * model.c)) * (180 / Math.PI);
            model.Gamma = 180 - model.Alpha - model.Beta; // Redondear por precisión numérica

            return View("Resultado", model);
        }
    }
}
