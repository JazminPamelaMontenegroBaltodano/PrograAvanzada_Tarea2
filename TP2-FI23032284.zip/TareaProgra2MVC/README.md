# Tarea Programada 2 - Programación Avanzada
# Carné: FI23032284

# Repositorio
- https://github.com/JazminPamelaMontenegroBaltodano/PrograAvanzada_Tarea2

# Fuentes consultadas
- https://openstax.org/books/prec%C3%A1lculo-2ed/pages/8-2-triangulos-no-rectangulos-ley-de-cosenos




# Prompts de IA utilizados
# Herramienta: ChatGPT  
# Prompt: Cómo aplicar ley de cosenos en C# para obtener ángulos de un triángulo con sus lados?
# Respuesta resumida: Usar Math.Acos(...) y convertir a grados con * (180 / Math.PI).
# Prompt: Cómo validar la desigualdad triangular en un modelo MVC de ASP.NET?
# Respuesta resumida: Ordenar lados y comprobar que la suma de los dos menores es mayor al tercero.

